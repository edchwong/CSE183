"""
This file defines the database models
"""

import datetime
from .common import db, Field, auth
from pydal.validators import *


def get_user():
    return auth.current_user.get('id') if auth.current_user else None

def get_user_email():
    return auth.current_user.get('email') if auth.current_user else None

def get_first_name():
    return auth.current_user.get('first_name') if auth.current_user else None

def get_last_name():
    return auth.current_user.get('last_name') if auth.current_user else None

def get_time():
    return datetime.datetime.utcnow()


db.define_table('post_table',
    Field('text', required=True),
    Field('email', default=get_user_email),
    Field('first_name', default=get_first_name),
    Field('last_name', default=get_last_name),
    Field('last_modified', default=get_time)
)

db.define_table('rating_table',
    Field('post', 'reference post_table'),
    Field('user', 'reference auth_user', default=get_user),
    Field('rating', 'integer', default=0)
)

db.commit()
