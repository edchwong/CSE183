// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        user_email: "",
        post_mode: false,
        post_text: "",
        rows: [],
    };

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._id = k++;});
        return a;
    };

    app.detail = (a) => {
        // initializes useful fields for the posts
        a.map((e) => {
            e.rating = 0;
            e.show_raters = false;
            e.rating_string = "";
        });
        return a;
    };

    app.set_post_mode = function(new_post_mode) {
        app.vue.post_text = "";
        app.vue.post_mode = new_post_mode;
    };

    app.add_post = function() {
        // if there is any text, add the post to the database
        if (app.vue.post_text) {
            axios.post(add_post_url,
                {
                    post_text: app.vue.post_text,
                }
            ).then(function (response) {
                app.set_post_mode(false);
                let row = response.data.row;
                row.rating = 0;
                row.show_raters = false;
                row.rating_string = "";
                
                app.vue.rows.unshift(row);
                app.enumerate(app.vue.rows);
            });
        }
    };

    app.delete_post = function(row_id) {
        let id = app.vue.rows[row_id].id;
        axios.get(delete_post_url, {
            params: {
                "id": id,
            }
        }).then(function (response) {
            for (let i = 0; i < app.vue.rows.length; i++) {
                if (app.vue.rows[i].id === id) {
                    app.vue.rows.splice(i, 1);
                    app.enumerate(app.vue.rows);
                    break;
                }
            }
        });
    };

    app.toggle_like = function(row_id) {
        let row = app.vue.rows[row_id];
        let next_rating = 0;
        if (row.rating <= 0) {
            next_rating = 1
        }

        axios.post(set_rating_url, {
            post: row.id,
            rating: next_rating,
        }).then(function (response) {
            let new_row = row;
            new_row.rating = next_rating;
            new_row.rating_string = "";
            Vue.set(app.vue.rows, row_id, new_row);
            app.show_ratings(row_id);
        });
    };

    app.toggle_dislike = function(row_id) {
        let row = app.vue.rows[row_id];
        let next_rating = 0;
        if (row.rating >= 0) {
            next_rating = -1
        }

        axios.post(set_rating_url, {
            post: row.id,
            rating: next_rating,
        }).then(function (response) {
            let new_row = row;
            new_row.rating = next_rating;
            new_row.rating_string = "";
            Vue.set(app.vue.rows, row_id, new_row);
            app.show_ratings(row_id);
        });
    };

    app.show_ratings = function(row_id) {
        let row = app.vue.rows[row_id];
        let new_row = row;
        new_row.show_raters = true;
        if (row.rating_string === "") {
            axios.get(get_all_ratings_url, {
                params: {
                    "post_id": row.id,
                }
            }).then(function (response) {
                let liked_by = response.data.liked_by;
                let disliked_by = response.data.disliked_by;
                let full_str = "";
                if (liked_by != "") {
                    full_str += "Liked by ";
                    full_str += liked_by;
                }
                full_str += " ";
                if (disliked_by != "") {
                    full_str += "Disliked by ";
                    full_str += disliked_by;
                }
                new_row.rating_string = full_str;
                Vue.set(app.vue.rows, row_id, new_row);
            });
        } else {
            Vue.set(app.vue.rows, row_id, new_row);
        }
    };

    app.turn_off_ratings = function(row_id) {
        let row = app.vue.rows[row_id];
        let new_row = row;
        new_row.show_raters = false;
        Vue.set(app.vue.rows, row_id, new_row);
        app.vue.rating_string = "";
    };

    // This contains all the methods.
    app.methods = {
        set_post_mode: app.set_post_mode,
        add_post: app.add_post,
        delete_post: app.delete_post,
        toggle_like: app.toggle_like,
        toggle_dislike: app.toggle_dislike,
        show_ratings: app.show_ratings,
        turn_off_ratings: app.turn_off_ratings,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // load posts and initialize rows
        let rows;
        axios.get(load_posts_url).then(function (response) {
            app.vue.user_email = response.data.user_email;
            rows = response.data.rows.reverse();
            app.enumerate(rows);
            app.detail(rows);
        }).then(() => {
            // initialize all post ratings
            for (let row of rows) {
                axios.get(get_rating_url, {
                    params: {
                        "id": row.id,
                    }
                }).then(function (response) {
                    row.rating = response.data.rating;
                });
            }
            app.vue.rows = rows;
        });
    };

    // Call to the initializer.
    app.init();
};

// initializes app
init(app);
