"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

from py4web import action, request, abort, redirect, URL
from yatl.helpers import A
from .common import db, session, T, cache, auth, logger, authenticated, unauthenticated, flash
from py4web.utils.url_signer import URLSigner
from .models import get_user_email, get_user, get_first_name, get_last_name

url_signer = URLSigner(session)

@action('index')
@action.uses('index.html', db, auth.user, url_signer)
def index():
    return dict(
        load_posts_url = URL('load_posts', signer=url_signer),
        add_post_url = URL('add_post', signer=url_signer),
        delete_post_url = URL('delete_post', signer=url_signer),
        get_rating_url = URL('get_rating', signer=url_signer),
        set_rating_url = URL('set_rating', signer=url_signer),
        get_all_ratings_url = URL('get_all_ratings', signer=url_signer),
    )


@action('load_posts')
@action.uses(db, url_signer.verify())
def load_posts():
    rows = db().select(db.post_table.ALL, 
        orderby=db.post_table.last_modified).as_list()
    return dict(
        rows = rows,
        user_email = get_user_email()
    )


@action('add_post', method='POST')
@action.uses(db, url_signer.verify())
def add_post():
    id = db.post_table.insert(text = request.json.get('post_text'))
    row = db.post_table[id]
    return dict(
        row=row
    )


@action('delete_post')
@action.uses(db, url_signer.verify())
def delete_post():
    id = request.params.get('id')
    assert id != None
    db(db.post_table.id == id).delete()
    return "ok"


@action('get_rating')
@action.uses(db, url_signer.verify())
def get_rating():
    post_id = request.params.get('id')
    row = db((db.rating_table.post == post_id) &
             (db.rating_table.user == get_user())).select().first()
    rating = row.rating if row else 0
    return dict(rating=rating)


@action('get_all_ratings')
@action.uses(db, url_signer.verify())
def get_all_ratings():
    post_id = request.params.get('post_id')
    assert post_id != None
    rows = db(db.rating_table.post == post_id).select()

    liked_by = []
    disliked_by = []
    for row in rows:
        if row.rating == 0:
            continue
        user = db.auth_user[row.user]
        name = user.first_name + ' ' + user.last_name if user != None else "unknown"
        if row.rating > 0:
            liked_by.append(name)
        else:
            disliked_by.append(name)

    return dict(
        liked_by = ', '.join(liked_by),
        disliked_by = ', '.join(disliked_by),
    )


@action('set_rating', method='POST')
@action.uses(db, url_signer.verify())
def set_rating():
    user = get_user()
    post = request.params.get('post')
    rating = request.params.get('rating')

    db.rating_table.update_or_insert((db.rating_table.post == post) &
        (db.rating_table.user == user),
        post = post,
        user = user,
        rating = rating
    )

    row = db(db.rating_table.post == post).select().first()

    return "ok"
