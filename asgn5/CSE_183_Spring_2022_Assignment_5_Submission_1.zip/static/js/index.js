// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        // Complete as you see fit.
        add_mode: false,
        add_text: "",
        rows: [],
    };

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;
    };
    
    app.complete = (rows) => {
        // Initializes useful fields of images.
        rows.map((r) => {
            r.rating = 0;
            r.hover = 0;
        })
    };

    app.set_add_mode = function(new_status) {
        app.vue.add_mode = new_status;
        app.vue.add_text = "";
    };
    
    app.add_post = function() {
        axios.post(add_post_url,
            {
                text: app.vue.add_text,
            }).then(function (response) {
            app.vue.rows.unshift({
                id: response.data.id,
                text: app.vue.add_text,
                author: response.data.name,
                rating: 0,
                hover: 0,
            });
            app.enumerate(app.vue.rows);
            app.set_add_mode(false);
        });
    };
    
    app.delete_post = function(row_idx) {
        let id = app.vue.rows[row_idx].id;
        axios.get(delete_post_url, {params: {id: id}}).then(function (response) {
            for (let i = 0; i < app.vue.rows.length; i++) {
                if (app.vue.rows[i].id === id) {
                    app.vue.rows.splice(i, 1);
                    app.enumerate(app.vue.rows);
                    break;
                }
            }
        });
    };
    
    app.set_hover = function(row_idx, val) {
        let row = app.vue.rows[row_idx];
        row.hover = val;
    };
    
    app.set_rating = function(r_idx, rat) {
        let row = app.vue.rows[r_idx];
        row.rating = rat;
        // Sets the likes on the server.
        axios.post(set_rating_url, {post_id: row.id, rating: rat});
    };

    // This contains all the methods.
    app.methods = {
        // Complete as you see fit.
        set_add_mode: app.set_add_mode,
        add_post: app.add_post,
        delete_post: app.delete_post,
        set_rating: app.set_rating,
        set_hover: app.set_hover,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        // Typically this is a server GET call to load the data.
        axios.get(load_posts_url)
            .then((result) => {
                // We set them
                let rows = result.data.rows;
                app.enumerate(rows);
                app.complete(rows);
                app.vue.rows = rows;
            })
            .then(() => {
                // Then we get the star ratings for each image.
                // These depend on the user.
                for (let r of app.vue.rows) {
                    axios.get(get_rating_url, {params: {"post_id": r.id}})
                        .then((result) => {
                            r.rating = result.data.rating;
                        });
                }
            });
    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code i
init(app);
