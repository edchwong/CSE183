// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        // Complete as you see fit.
        add_mode: false,
        show_raters: false,
        add_post_entry: "",
        current_user_email: "",
        posts: [],
    };

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;
    };

    app.complete = (posts) => {
        posts.map((pst) => {
            pst.like = false;
            pst.dislike = false;
            pst.likers = [];
            pst.dislikers = [];
        })
    };

    app.add_post = function () {
        axios.post(add_post_url,
            {
                post_entry: app.vue.add_post_entry,
            }).then(function (response) {
            app.vue.posts.push({
                id: response.data.id,
                post_entry: app.vue.add_post_entry,
                post_name: response.data.name,
                post_email: response.data.email,
            });
            app.enumerate(app.vue.posts);
            app.reset_form();
            app.set_add_status(false);
        });
    };

    app.reset_form = function() {
        app.vue.add_post_entry = "";
    };

    app.delete_post = function (row_idx) {
        let id = app.vue.posts[row_idx].id;
        axios.get(delete_post_url, {params: {id: id}}).then(function (response) {
            for(let i = 0; i < app.vue.posts.length; i++){
                if(app.vue.posts[i].id == id) {
                    app.vue.posts.splice(i, 1);
                    app.enumerate(app.vue.posts);
                    break;
                }
            }
        });
    };

    app.set_add_status = function (new_status) {
        app.vue.add_mode = new_status;
    };

    app.show_delete = function (row) {
        if(row.post_email == app.vue.current_user_email){
            return true;
        } else {
            return false;
        }
    };


    app.like_post = (post_idx) => {
        let pst = app.vue.posts[post_idx];
        if(pst.like){
            pst.like = false;
            pst.dislike = false;
        } else {
            pst.like = true;
            pst.dislike = false;
        }
        axios.post(set_likes_url, {post_id: pst.id, like: pst.like, dislike: pst.dislike});
        axios.get(get_raters_url, {params: {post_id: pst.id}}).then((result) => {
                    pst.likers = result.data.likers;
                    pst.dislikers = result.data.dislikers;
                });
    };

    app.dislike_post = function (post_idx) {
        let pst = app.vue.posts[post_idx];
        if(pst.dislike){
            pst.like = false;
            pst.dislike = false;
        } else {
            pst.like = false;
            pst.dislike = true;
        }
        axios.post(set_likes_url, {post_id: pst.id, like: pst.like, dislike: pst.dislike});
        axios.get(get_raters_url, {params: {post_id: pst.id}}).then((result) => {
                    pst.likers = result.data.likers;
                    pst.dislikers = result.data.dislikers;
                });
    }

    app.show_likes_dislikes = function (new_status) {
        app.vue.show_raters = new_status;
    };

    // This contains all the methods.
    app.methods = {
        // Complete as you see fit.
        add_post: app.add_post,
        set_add_status: app.set_add_status,
        delete_post: app.delete_post,
        show_delete: app.show_delete,
        like_post: app.like_post,
        dislike_post: app.dislike_post,
        show_likes_dislikes: app.show_likes_dislikes
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        // Typically this is a server GET call to load the data.
        axios.get(load_posts_url).then(function (response) {
            app.complete(response.data.rows);
            app.vue.posts = app.enumerate(response.data.rows);
            app.vue.current_user_email = response.data.current_user_email;
        }).then(() => {
            for(let post of app.vue.posts){
                axios.get(get_likes_url, {params: {post_id: post.id}}).then((result) => {
                    post.like = result.data.like;
                    post.dislike = result.data.dislike;
                });
                axios.get(get_raters_url, {params: {post_id: post.id}}).then((result) => {
                    post.likers = result.data.likers;
                    post.dislikers = result.data.dislikers;
                });
            }
        });

    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code i
init(app);
