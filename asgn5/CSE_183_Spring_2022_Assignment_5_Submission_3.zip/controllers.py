"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

from py4web import action, request, abort, redirect, URL
from yatl.helpers import A
from .common import db, session, T, cache, auth, logger, authenticated, unauthenticated, flash
from py4web.utils.url_signer import URLSigner
from .models import get_user_email, get_user

url_signer = URLSigner(session)

@action('index')
@action.uses(db, auth, url_signer, 'index.html', auth.user)
def index():
    return dict(
        # COMPLETE: return here any signed URLs you need.
        load_posts_url = URL('load_posts', signer=url_signer),
        add_post_url = URL('add_post', signer=url_signer),
        delete_post_url = URL('delete_post', signer=url_signer),
        set_likes_url = URL('set_likes', signer=url_signer),
        get_likes_url = URL('get_likes', signer=url_signer),
        get_raters_url = URL('get_raters', signer=url_signer),
    )

@action('load_posts')
@action.uses(db, url_signer.verify())
def load_posts():
    current_user_email = get_user_email()
    rows = db(db.posts).select().as_list()
    r = db(db.auth_user.email == get_user_email()).select().first()
    name = r.first_name + " " + r.last_name if r is not None else "Unknown"
    return dict(rows=rows, name=name, current_user_email=current_user_email)

@action('add_post', method="POST")
@action.uses(db, url_signer.verify())
def add_post():
    r = db(db.auth_user.email == get_user_email()).select().first()
    name = r.first_name + " " + r.last_name if r is not None else "Unknown"
    email = get_user_email()
    id = db.posts.insert(
        post_entry=request.json.get('post_entry'),
        post_name=name,
        post_email=email,
    )
    return dict(id=id, name=name, email=email)

@action('delete_post')
@action.uses(url_signer.verify(), db,session, auth.user)
def delete_post():
    id=request.params.get('id')
    assert id is not None
    db(db.likes.post == id).delete()
    db(db.posts.id == id).delete()
    return "ok"

@action('set_likes', method="POST")
@action.uses(url_signer.verify(), db, auth.user)
def set_likes():
    post_id = int(request.params.get('post_id'))
    like = request.params.get('like')
    dislike = request.params.get('dislike')
    assert post_id is not None and like is not None and dislike is not None
    db.likes.update_or_insert(
        ((db.likes.post == post_id) & (db.likes.liker == get_user())),
        post=post_id,
        like=like,
        dislike=dislike,
        liker=get_user()
    )
    return "ok"

@action('get_likes')
@action.uses(url_signer.verify(), db, auth.user)
def get_likes():
    post_id = int(request.params.get('post_id'))
    row = db((db.likes.post == post_id) & (db.likes.liker == get_user())).select().first()
    like = row.like if row is not None else False
    dislike = row.dislike if row is not None else False
    return dict(like=like, dislike=dislike)


@action('get_raters')
@action.uses(url_signer.verify(), db, auth.user)
def get_raters():
    post_id = int(request.params.get('post_id'))
    row = db((db.likes.post == post_id)).select().as_list()
    likers = []
    dislikers = []
    for r in row:
        if r["like"]:
            names = db(db.auth_user.id == r["liker"]).select().first()
            name = names.first_name + " " + names.last_name if names is not None else "Unknown"
            likers.append(name)
        elif r["dislike"]:
            names = db(db.auth_user.id == r["liker"]).select().first()
            name = names.first_name + " " + names.last_name if names is not None else "Unknown"
            dislikers.append(name)

    return dict(likers=likers, dislikers=dislikers)
