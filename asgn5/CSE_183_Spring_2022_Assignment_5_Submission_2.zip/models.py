"""
This file defines the database models
"""

import datetime
from .common import db, Field, auth
from pydal.validators import *


def get_user_email():
    return auth.current_user.get('email') if auth.current_user else None

def get_user():
    return auth.current_user.get('id') if auth.current_user else None

def get_time():
    return datetime.datetime.utcnow()


### Define your table below
#
# db.define_table('thing', Field('name'))
#
## always commit your models to avoid problems later
db.define_table('post',
                Field('email'),
                Field('first_name'),
                Field('last_name'), 
                Field('text'),
                )

db.define_table('likes', 
                Field('post', 'reference post'),
                Field('rating', 'integer', default = 0), # 0 = no rating, -1 = dislike, 1 = like
                Field('liker', 'reference auth_user')
                )

db.commit()
