// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        // Complete as you see fit.
        add_mode: false,
        add_first_name: "",
        add_last_name: "",
        add_text: "",
        rows:[],
        user_email: "",
        likers: [],
        dislikers: [],
    };
    

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;//.reverse();
    };


    app.complete = (posts) => {
        // Initializes useful fields of posts.
        posts.map((post) => {
            //post.first_name = post.first_name;
            //post.last_name = post.last_name;
            post.rating = 0;
            post.likes_display = 0;
        })
    };


    app.add_post = function () {

        // Added stuff
        let p = {
            first_name: app.vue.add_first_name,
            last_name: app.vue.add_last_name,
            text: app.vue.add_text,
        }
        app.vue.rows.unshift(p);
        app.complete(app.vue.rows);
        app.enumerate(app.vue.rows);
        axios.post(add_post_url,
            {
                first_name: p.first_name,
                last_name: p.last_name,
                text: p.text,
            }).then(() => {
                app.init();
            });
        app.reset_form();
        app.set_add_status(false);
        //app.init();

    };

    app.reset_form = function () {
        //app.vue.add_first_name = "";
        //app.vue.add_last_name = "";
        app.vue.add_text = "";
    };

    app.delete_post = function(row_idx) {
        let id = app.vue.rows[row_idx].id;
        axios.get(delete_post_url, {params: {id: id}}).then(function (response) {
            for (let i = 0; i < app.vue.rows.length; i++) {
                if (app.vue.rows[i].id === id) {
                    app.vue.rows.splice(i, 1);
                    app.enumerate(app.vue.rows);
                    break;
                }
            }
        });
    };

    app.set_rating = (row_idx, thumb_idx) => {
        let post = app.vue.rows[row_idx];
        post.rating = thumb_idx;
        //console.log(post)

        axios.post(set_rating_url, 
            {
                post_id: post.id, 
                rating: thumb_idx
            })
    };

    // when moust over thumbs, show filled in thumb
    app.thumbs_over = (row_idx, thumb_idx) => {
        let post = app.vue.rows[row_idx];
        post.likes_display = thumb_idx;
        axios.get(get_likers_url, {params: {"post_id": post.id}}).then (function (response) {
            //console.log(response.data);
            app.vue.likers = response.data.post_likers;
            app.vue.dislikers = response.data.post_dislikers;
        });
    
        
    };

    // when mouse not over thumbs, show rating
    app.thumbs_out = (row_idx) => {
        let post = app.vue.rows[row_idx];
        post.likes_display = post.rating;
       
    }

    app.set_add_status = function (new_status) {
        app.vue.add_mode = new_status;
    };



    // This contains all the methods.
    app.methods = {
        // Complete as you see fit.
        add_post: app.add_post,
        set_add_status: app.set_add_status,
        delete_post: app.delete_post,
        set_rating: app.set_rating,
        thumbs_over: app.thumbs_over,
        thumbs_out: app.thumbs_out,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        // Typically this is a server GET call to load the data.
        axios.get(user_email_url)
            .then(function(response) {
                app.vue.user_email = response.data;
                //console.log(response);
        });
        
        axios.get(load_posts_url)
            .then(function (response) {
                let posts = response.data.rows.reverse();
                app.enumerate(posts);
                app.complete(posts);
                app.vue.rows = posts;
                //console.log("HERE");
        })
        .then(() => {
            for (let post of app.vue.rows) {
                axios.get(get_rating_url, {params: {"post_id": post.id}})
                    .then((response) => {
                        
                        // Post doesn't have a rating attribute, may need to add one in models.py
                        //post.rating = response.data.rating;
                        post.likes_display = response.data.rating;
                        console.log(response)
                    });
            }
        });
    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code i
init(app);
