"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

from py4web import action, request, abort, redirect, URL
from yatl.helpers import A
from .common import db, session, T, cache, auth, logger, authenticated, unauthenticated, flash
from py4web.utils.url_signer import URLSigner
from .models import get_user_email

url_signer = URLSigner(session)

@action('index')
@action.uses(db, auth, 'index.html', url_signer, auth.user)
def index():
    return dict(
        # COMPLETE: return here any signed URLs you need.
        load_comment_url = URL('load_comment', signer=url_signer),
        my_callback_url = URL('my_callback', signer=url_signer),
        add_comment_url = URL('add_comment', signer=url_signer),
        delete_comment_url = URL('delete_comment', signer=url_signer),
        like_post_url = URL('like_post', signer=url_signer),
        dislike_post_url = URL('dislike_post', signer=url_signer),
        over_like_url = URL('over_like', signer=url_signer),
        over_dislike_url = URL('over_dislike', signer=url_signer),
        get_rating_url = URL('get_rating', signer=url_signer)
    )


@action('add_comment', method="POST")
@action.uses(url_signer.verify(), auth.user,db)
def add_comment():
    user = db(db.auth_user.email == get_user_email()).select().first()
    id = db.posts.insert(
        comment=request.json.get('comment'),
        email=get_user_email(),
        name= user.first_name + " " + user.last_name,
        total_dislikes = 0,
        total_likes = 0
    )
    email=get_user_email()
    name=user.first_name + " " + user.last_name
    return dict(id=id,comment=db.posts[id].comment, email=email, name=name)


@action('load_comment')
@action.uses(url_signer.verify(), db)
def load_comment():
    rows = db(db.posts).select().as_list()
    
    reactions = db(db.ratings).select().as_list()
    my_reactions = db((db.ratings.rater_email == get_user_email())).select().as_list()
    return dict(
        rows=rows, 
        user_email=get_user_email(),
        reactions=reactions,
        my_reactions = my_reactions
    ) 


@action('delete_comment')
@action.uses(url_signer.verify(),db)
def delete_comment():
    id = request.params.get('id')
    assert id is not None
    db(db.posts.id == id).delete()
    return "ok"

@action('like_post', method="POST")
@action.uses(url_signer.verify(),db,auth.user)
def like_post():
    id = request.json.get('id')
    user_email = request.json.get('email')
    like_reaction = db((db.ratings.post_id == id) & (db.ratings.rater_email == user_email)).select('like')
    dislike_reaction = db((db.ratings.post_id == id) & (db.ratings.rater_email == user_email)).select('dislike')

    if like_reaction is None:
        like_status = False
    else:
        if like_reaction == True:
            like_status = False
        else:
            like_status = True
    
    db.ratings.update_or_insert(
        ((db.ratings.post_id == id) & (db.ratings.rater_email == user_email)),
        post_id=id,
        dislike=False,
        like = like_status
        #like = either true or false
    )
    return "ok"

@action('dislike_post', method="POST")
@action.uses(url_signer.verify(), db, auth.user)
def dislike_post():
    id = request.json.get('id')
    user_email = request.json.get('email')
    like_reaction = db((db.ratings.post_id == id) & (db.ratings.rater_email == user_email)).select('like')
    dislike_reaction = db((db.ratings.post_id == id) & (db.ratings.rater_email == user_email)).select('dislike')

    if dislike_reaction is None:
        dislike_status = True
    else:
        if dislike_reaction == True:
            dislike_status = False
        else:
            dislike_status = True
    
    db.ratings.update_or_insert(
        ((db.ratings.post_id == id) & (db.ratings.rater_email == user_email)),
        post_id=id,
        dislike=dislike_status,
        like = False
        #like = either true or false
    )
    return "ok"

@action('get_rating', method = ["GET","POST"])
@action.uses(url_signer.verify(), db, auth.user)
def get_rating():
    post_id = request.params.get('post_id')
    row = db((db.ratings.post_id == post_id) & (db.ratings.rater_email == get_user_email())).select().first()
    if row is not None:
        like = row.like
        dislike = row.dislike
    elif row is None: 
        like = False
        dislike = False

    return dict(like=like, dislike=dislike)