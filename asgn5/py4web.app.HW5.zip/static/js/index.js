// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        // Complete as you see fit.
        add_mode: false,
        add_comment: "",
        rows:[],
        user_email: "",
        reactions:[],
    };

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;
    };

    app.set_add_mode = function (new_status){
        app.reset_form();
        app.vue.add_mode = new_status;
    }

    app.adding_comment = function(){ 
        axios.post(add_comment_url, 
            {  
                comment: app.vue.add_comment
            }).then(function(response) { 
                row = app.vue.rows.unshift({
                    id: response.data.id,
                    comment: app.vue.add_comment,
                    email: response.data.email,
                    name: response.data.name,
                    total_likes: 0,
                    total_dislikes: 0,
                    like: false,
                    dislike: false
                })
                app.enumerate(app.vue.rows);
                app.set_add_mode(new_status=false);
            })
        
    };

    app.delete_comment = function(row_idx){
        let id = app.vue.rows[row_idx].id;
        axios.get(delete_comment_url, {params: {id: id}}).then(function(response){
            for (let i=0; i < app.vue.rows.length; i++) {
                for (let j=0; j < app.vue.reactions.length; j++) {
                    if (app.vue.reactions[j].post_id == id){
                        app.vue.rows.splice(i,1);
                        app.vue.enumerate(app.vue.reactions);
                        j--;
                    }
                }
                if (app.vue.rows[i].id == id) {
                    app.vue.rows.splice(i,1);
                    app.enumerate(app.vue.rows);
                    break;
                }
            }
        });
        
    };

    app.reset_form = function() {
        app.vue.add_comment = ""
    }

    app.like_post = function(row_idx){
        let id = app.vue.rows[row_idx].id;
        axios.post(like_post_url, {id: id, email: app.vue.user_email});
        app.init();
    };

    app.dislike_post = function(row_idx) {
        let id = app.vue.rows[row_idx].id;
        axios.post(dislike_post_url, {id: id, email: app.vue.user_email});
        app.init();
    };

    app.over_like = function(row_idx, like_status){
        let id = app.vue.rows[row_idx].id;
        
    };

    app.over_dislike = function() {

    };

    app.complete = (rows) => {
        rows.map((post) => {
            post.like = false;
            post.dislike = false;
        })
    };
    // This contains all the methods.
    app.methods = {
        // Complete as you see fit.
        adding_comment: app.adding_comment,
        delete_comment: app.delete_comment,
        set_add_mode: app.set_add_mode,
        like_post: app.like_post,
        dislike_post: app.dislike_post,
        over_like: app.over_like,
        over_dislike: app.over_like,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        // Typically this is a server GET call to load the data.
        axios.get(load_comment_url).then(function(response){
            let rows = response.data.rows.reverse();
            app.enumerate(rows);
            app.complete(rows);
            app.vue.rows = rows;
            app.vue.user_email = response.data.user_email;
            app.vue.reactions = app.enumerate(response.data.reactions);
        }).then(()=> {
            for (let row of app.vue.rows) {
                //console.log(row.id);
                axios.get(get_rating_url, {params: {post_id: row.id}})
                    .then((result) => {
                        row.like = result.data.like;
                        row.dislike = result.data.dislike;
                    });
            }
        });
        

    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code i
init(app);
