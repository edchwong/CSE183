"""
This file defines the database models
"""

import datetime
from .common import db, Field, auth
from pydal.validators import *


def get_user_email():
    return auth.current_user.get('email') if auth.current_user else None

def get_time():
    return datetime.datetime.utcnow()


### Define your table below
#
# db.define_table('thing', Field('name'))
# 
## always commit your models to avoid problems later

db.define_table(
    'posts',
    Field('comment', requires=IS_NOT_EMPTY()),
    Field('email', default=get_user_email,writable=False,readable=False),
    Field('total_likes', default=0),
    Field('total_dislikes', default=0),
    Field('name'),
)

db.define_table(
    'ratings',
    Field('post_id', 'reference posts', ondelete='CASCADE'),
    Field('rater_email', default=get_user_email),
    Field('like','boolean', default=False), # 1 = like -1 = dislike 0 = no rating
    Field('dislike', 'boolean',default=False),
)

db.commit()
